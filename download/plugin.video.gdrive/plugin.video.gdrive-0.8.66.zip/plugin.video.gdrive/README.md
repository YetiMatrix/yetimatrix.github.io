Refer to branch "OLD-GDRIVE-V0.8.66" for the original code.
